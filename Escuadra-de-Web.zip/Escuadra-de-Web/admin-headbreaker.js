document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();

  const form = document.getElementById('formImagen');
  const inputTitulo = document.getElementById('titulo');
  const inputArchivo = document.getElementById('archivo');
  const preview = document.getElementById('preview');
  const previewImg = document.getElementById('previewImg');
  const previewMeta = document.getElementById('previewMeta');
  const alerta = document.getElementById('formAlert');
  const btnSubir = document.getElementById('btnSubir');
  const grid = document.getElementById('grid');
  const resumen = document.getElementById('resumen');

  let dimensiones = { ancho: null, alto: null };

  function mostrarAlerta(texto, tipo) {
    alerta.className = `alert alert-${tipo} mb-0`;
    alerta.textContent = texto;
  }

  async function cargarImagenes() {
    try {
      const imagenes = await api(`/api/admin/headbreaker/imagenes?usuario=${usuario}`);
      const activas = imagenes.filter((i) => i.activa).length;
      resumen.textContent = `${activas} activa(s) de ${imagenes.length}`;

      grid.innerHTML = imagenes.map((i) => `
        <div class="hb-card ${i.activa ? '' : 'is-inactiva'}">
          <div class="hb-thumb"><img src="${API_URL}/${esc(i.archivo)}" alt="${esc(i.titulo)}" loading="lazy"
               onerror="this.parentElement.classList.add('sin-archivo')"></div>
          <div class="hb-card-body">
            <div class="hb-titulo">${esc(i.titulo)}</div>
            <div class="hb-meta">${i.ancho_px ? `${i.ancho_px} × ${i.alto_px} px · ` : ''}jugada ${i.veces_jugada} ${i.veces_jugada === 1 ? 'vez' : 'veces'}</div>
            <div class="hb-meta">Subió ${esc(i.subida_por)} · ${formatoFecha(i.fecha_subida)}</div>
            <button type="button" class="btn btn-sm ${i.activa ? 'btn-outline-danger' : 'btn-outline-success'} mt-2"
                    data-id="${i.id_imagen}" data-activa="${i.activa ? 0 : 1}">
              ${i.activa ? '<i class="bi bi-eye-slash"></i> Quitar del juego' : '<i class="bi bi-eye"></i> Volver a poner'}
            </button>
          </div>
        </div>`).join('');
    } catch (e) {
      document.getElementById('contenido').classList.add('d-none');
      const a = document.getElementById('alertaAcceso');
      a.classList.remove('d-none');
      a.textContent = e.message;
    }
  }

  grid.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-id]');
    if (!btn) return;
    btn.disabled = true;
    try {
      await api(`/api/admin/headbreaker/imagenes/${btn.dataset.id}`,
        jsonBody('PUT', { usuario, activa: btn.dataset.activa === '1' }));
      cargarImagenes();
    } catch (err) {
      alert(err.message);
      btn.disabled = false;
    }
  });

  inputArchivo.addEventListener('change', () => {
    const archivo = inputArchivo.files[0];
    dimensiones = { ancho: null, alto: null };
    if (!archivo) return preview.classList.add('d-none');

    const url = URL.createObjectURL(archivo);
    previewImg.onload = () => {
      dimensiones = { ancho: previewImg.naturalWidth, alto: previewImg.naturalHeight };
      previewMeta.textContent = `${dimensiones.ancho} × ${dimensiones.alto} px · ${(archivo.size / 1024 / 1024).toFixed(1)} MB`;
    };
    previewImg.src = url;
    preview.classList.remove('d-none');
    if (!inputTitulo.value) inputTitulo.value = archivo.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!inputTitulo.value.trim()) return mostrarAlerta('Ponle un título a la imagen.', 'danger');
    if (!inputArchivo.files[0]) return mostrarAlerta('Selecciona una imagen.', 'danger');

    const datos = new FormData();
    datos.append('usuario', usuario);
    datos.append('titulo', inputTitulo.value.trim());
    if (dimensiones.ancho) {
      datos.append('ancho', dimensiones.ancho);
      datos.append('alto', dimensiones.alto);
    }
    datos.append('imagen', inputArchivo.files[0]);

    btnSubir.disabled = true;
    try {
      const r = await api('/api/admin/headbreaker/imagenes', { method: 'POST', body: datos });
      mostrarAlerta(`"${r.titulo}" ya está disponible en Head Breaker.`, 'success');
      form.reset();
      preview.classList.add('d-none');
      cargarImagenes();
    } catch (err) {
      mostrarAlerta(err.message, 'danger');
    } finally {
      btnSubir.disabled = false;
    }
  });

  cargarImagenes();
});
