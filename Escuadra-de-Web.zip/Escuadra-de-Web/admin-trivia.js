document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();

  const form = document.getElementById('formPregunta');
  const tituloForm = document.getElementById('tituloForm');
  const inputPregunta = document.getElementById('pregunta');
  const inputDificultad = document.getElementById('dificultad');
  const inputsOpciones = Array.from(document.querySelectorAll('#opciones .opcion'));
  const marcas = Array.from(document.querySelectorAll('#opciones .marca'));
  const alerta = document.getElementById('formAlert');
  const btnGuardar = document.getElementById('btnGuardar');
  const btnCancelar = document.getElementById('btnCancelar');
  const lista = document.getElementById('lista');
  const resumen = document.getElementById('resumen');

  const NIVELES = { 1: 'Fácil', 2: 'Medio', 3: 'Difícil' };

  let preguntas = [];
  let editando = null;

  function mostrarAlerta(texto, tipo) {
    alerta.className = `alert alert-${tipo} mb-0`;
    alerta.textContent = texto;
  }

  function limpiarFormulario() {
    editando = null;
    form.reset();
    tituloForm.textContent = 'Nueva pregunta';
    btnCancelar.classList.add('d-none');
    alerta.className = 'alert d-none mb-0';
  }

  async function cargarPreguntas() {
    try {
      preguntas = await api(`/api/admin/trivia?usuario=${usuario}`);
      const activas = preguntas.filter((p) => p.activa).length;
      resumen.textContent = `${activas} activa(s) de ${preguntas.length}`;

      if (preguntas.length === 0) {
        lista.innerHTML = '<div class="text-muted">Todavía no hay preguntas. Escribe la primera.</div>';
        return;
      }

      lista.innerHTML = preguntas.map((p) => `
        <div class="pq-card ${p.activa ? '' : 'is-inactiva'}">
          <div class="pq-card-top">
            <div class="pq-texto">${esc(p.texto)}</div>
            <span class="badge ${p.activa ? 'text-bg-success' : 'text-bg-secondary'}">${p.activa ? 'Activa' : 'Oculta'}</span>
          </div>
          <ul class="pq-pasos">${p.opciones.map((t, i) => `<li>${esc(t)}${i === p.correcta ? ' <i class="bi bi-check-circle-fill text-success"></i>' : ''}</li>`).join('')}</ul>
          <div class="pq-meta">${NIVELES[p.dificultad] || p.dificultad} · respondida ${p.respuestas} ${p.respuestas === 1 ? 'vez' : 'veces'}${p.respuestas ? ` · ${p.aciertos} acierto(s)` : ''}</div>
          <div class="pq-acciones">
            <button type="button" class="btn btn-sm btn-outline-primary" data-accion="editar" data-id="${p.id_pregunta}">
              <i class="bi bi-pencil"></i> Editar
            </button>
            <button type="button" class="btn btn-sm ${p.activa ? 'btn-outline-danger' : 'btn-outline-success'}"
                    data-accion="estado" data-id="${p.id_pregunta}" data-activa="${p.activa ? 0 : 1}">
              ${p.activa ? '<i class="bi bi-eye-slash"></i> Quitar del juego' : '<i class="bi bi-eye"></i> Volver a poner'}
            </button>
          </div>
        </div>`).join('');
    } catch (e) {
      document.getElementById('contenido').classList.add('d-none');
      const a = document.getElementById('alertaAcceso');
      a.classList.remove('d-none');
      a.textContent = e.message;
    }
  }

  lista.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-accion]');
    if (!btn) return;
    const id = Number(btn.dataset.id);

    if (btn.dataset.accion === 'editar') {
      const p = preguntas.find((x) => x.id_pregunta === id);
      if (!p) return;
      editando = id;
      inputPregunta.value = p.texto;
      inputDificultad.value = String(p.dificultad);
      inputsOpciones.forEach((input, i) => { input.value = p.opciones[i] || ''; });
      marcas.forEach((m, i) => { m.checked = i === p.correcta; });
      tituloForm.textContent = 'Editar pregunta';
      btnCancelar.classList.remove('d-none');
      alerta.className = 'alert d-none mb-0';
      inputPregunta.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    btn.disabled = true;
    try {
      await api(`/api/admin/trivia/${id}/estado`,
        jsonBody('PUT', { usuario, activa: btn.dataset.activa === '1' }));
      if (editando === id && btn.dataset.activa === '0') limpiarFormulario();
      cargarPreguntas();
    } catch (err) {
      alert(err.message);
      btn.disabled = false;
    }
  });

  btnCancelar.addEventListener('click', limpiarFormulario);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const texto = inputPregunta.value.trim();
    const indice = marcas.findIndex((m) => m.checked);
    const llenas = inputsOpciones
      .map((input, i) => ({ texto: input.value.trim(), i }))
      .filter((o) => o.texto);

    if (!texto) return mostrarAlerta('Escribe la pregunta.', 'danger');
    if (llenas.length < 2) return mostrarAlerta('Escribe al menos 2 opciones.', 'danger');
    if (!llenas.some((o) => o.i === indice)) return mostrarAlerta('Marca como correcta una opción que tenga texto.', 'danger');
    if (new Set(llenas.map((o) => o.texto.toLowerCase())).size !== llenas.length) return mostrarAlerta('Las opciones deben ser distintas.', 'danger');

    const cuerpo = {
      usuario,
      pregunta: texto,
      dificultad: Number(inputDificultad.value),
      opciones: llenas.map((o) => o.texto),
      correcta: llenas.findIndex((o) => o.i === indice)
    };

    btnGuardar.disabled = true;
    try {
      if (editando) {
        await api(`/api/admin/trivia/${editando}`, jsonBody('PUT', cuerpo));
        mostrarAlerta('Pregunta actualizada.', 'success');
      } else {
        await api('/api/admin/trivia', jsonBody('POST', cuerpo));
        mostrarAlerta('Pregunta guardada. Ya puede salir en BrewStack.', 'success');
      }
      editando = null;
      form.reset();
      tituloForm.textContent = 'Nueva pregunta';
      btnCancelar.classList.add('d-none');
      cargarPreguntas();
    } catch (err) {
      mostrarAlerta(err.message, 'danger');
    } finally {
      btnGuardar.disabled = false;
    }
  });

  cargarPreguntas();
});
