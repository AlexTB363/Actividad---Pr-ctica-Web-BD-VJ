document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();

  const form = document.getElementById('formPregunta');
  const tituloForm = document.getElementById('tituloForm');
  const inputPregunta = document.getElementById('pregunta');
  const inputDificultad = document.getElementById('dificultad');
  const inputsPasos = Array.from(document.querySelectorAll('#pasos .paso'));
  const alerta = document.getElementById('formAlert');
  const btnGuardar = document.getElementById('btnGuardar');
  const btnCancelar = document.getElementById('btnCancelar');
  const lista = document.getElementById('lista');
  const resumen = document.getElementById('resumen');

  const NIVELES = { 1: 'Nivel 1', 2: 'Nivel 2', 3: 'Nivel 3' };

  let preguntas = [];
  let editando = null;

  function mostrarAlerta(texto, tipo) {
    alerta.className = `alert alert-${tipo} mb-0`;
    alerta.textContent = texto;
  }

  function limpiarFormulario() {
    editando = null;
    form.reset();
    tituloForm.textContent = 'Nueva pregunta';
    btnCancelar.classList.add('d-none');
    alerta.className = 'alert d-none mb-0';
  }

  async function cargarPreguntas() {
    try {
      preguntas = await api(`/api/admin/preguntas?usuario=${usuario}`);
      const activas = preguntas.filter((p) => p.activa).length;
      resumen.textContent = `${activas} activa(s) de ${preguntas.length}`;

      if (preguntas.length === 0) {
        lista.innerHTML = '<div class="text-muted">Todavía no hay preguntas. Escribe la primera.</div>';
        return;
      }

      lista.innerHTML = preguntas.map((p) => `
        <div class="pq-card ${p.activa ? '' : 'is-inactiva'}">
          <div class="pq-card-top">
            <div class="pq-texto">${esc(p.texto)}</div>
            <span class="badge ${p.activa ? 'text-bg-success' : 'text-bg-secondary'}">${p.activa ? 'Activa' : 'Oculta'}</span>
          </div>
          <ol class="pq-pasos">${p.pasos.map((t) => `<li>${esc(t)}</li>`).join('')}</ol>
          <div class="pq-meta">${NIVELES[p.dificultad] || `Nivel ${p.dificultad}`} · respondida ${p.respuestas} ${p.respuestas === 1 ? 'vez' : 'veces'}${p.respuestas ? ` · ${p.aciertos} acierto(s)` : ''}</div>
          <div class="pq-acciones">
            <button type="button" class="btn btn-sm btn-outline-primary" data-accion="editar" data-id="${p.id_pregunta}">
              <i class="bi bi-pencil"></i> Editar
            </button>
            <button type="button" class="btn btn-sm ${p.activa ? 'btn-outline-danger' : 'btn-outline-success'}"
                    data-accion="estado" data-id="${p.id_pregunta}" data-activa="${p.activa ? 0 : 1}">
              ${p.activa ? '<i class="bi bi-eye-slash"></i> Quitar del juego' : '<i class="bi bi-eye"></i> Volver a poner'}
            </button>
          </div>
        </div>`).join('');
    } catch (e) {
      document.getElementById('contenido').classList.add('d-none');
      const a = document.getElementById('alertaAcceso');
      a.classList.remove('d-none');
      a.textContent = e.message;
    }
  }

  lista.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-accion]');
    if (!btn) return;
    const id = Number(btn.dataset.id);

    if (btn.dataset.accion === 'editar') {
      const p = preguntas.find((x) => x.id_pregunta === id);
      if (!p) return;
      editando = id;
      inputPregunta.value = p.texto;
      inputDificultad.value = String(p.dificultad);
      inputsPasos.forEach((input, i) => { input.value = p.pasos[i] || ''; });
      tituloForm.textContent = 'Editar pregunta';
      btnCancelar.classList.remove('d-none');
      alerta.className = 'alert d-none mb-0';
      inputPregunta.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    btn.disabled = true;
    try {
      await api(`/api/admin/preguntas/${id}/estado`,
        jsonBody('PUT', { usuario, activa: btn.dataset.activa === '1' }));
      if (editando === id && btn.dataset.activa === '0') limpiarFormulario();
      cargarPreguntas();
    } catch (err) {
      alert(err.message);
      btn.disabled = false;
    }
  });

  btnCancelar.addEventListener('click', limpiarFormulario);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const texto = inputPregunta.value.trim();
    const pasos = inputsPasos.map((i) => i.value.trim());

    if (!texto) return mostrarAlerta('Escribe la pregunta.', 'danger');
    if (pasos.some((p) => !p)) return mostrarAlerta('Llena los 4 pasos.', 'danger');
    if (new Set(pasos.map((p) => p.toLowerCase())).size !== 4) return mostrarAlerta('Los 4 pasos deben ser distintos.', 'danger');

    const cuerpo = { usuario, pregunta: texto, dificultad: Number(inputDificultad.value), pasos };

    btnGuardar.disabled = true;
    try {
      if (editando) {
        await api(`/api/admin/preguntas/${editando}`, jsonBody('PUT', cuerpo));
        mostrarAlerta('Pregunta actualizada.', 'success');
      } else {
        await api('/api/admin/preguntas', jsonBody('POST', cuerpo));
        mostrarAlerta('Pregunta guardada. Ya puede salir en Orbit Payment.', 'success');
      }
      editando = null;
      form.reset();
      tituloForm.textContent = 'Nueva pregunta';
      btnCancelar.classList.add('d-none');
      cargarPreguntas();
    } catch (err) {
      mostrarAlerta(err.message, 'danger');
    } finally {
      btnGuardar.disabled = false;
    }
  });

  cargarPreguntas();
});
