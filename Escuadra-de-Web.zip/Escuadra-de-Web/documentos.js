document.addEventListener('DOMContentLoaded', () => {
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('fileInput');
  const categoriaSelect = document.getElementById('categoriaSubida');
  const grid = document.getElementById('documentsGrid');

  const CATEGORIA_LABEL = {
    contratos: 'Contratos',
    fiscal: 'Fiscal',
    politicas: 'Políticas',
    capacitacion: 'Capacitación',
  };

  const formatBytes = (bytes) => (
    bytes < 1024 * 1024
      ? `${Math.max(1, Math.round(bytes / 1024))} KB`
      : `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  );

  const formatFechaHoy = () => {
    const hoy = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(hoy.getDate())}/${pad(hoy.getMonth() + 1)}/${hoy.getFullYear()}`;
  };

  // Tabs de filtro 
  document.querySelectorAll('input[name="docFilter"]').forEach((radio) => {
    radio.addEventListener('change', () => aplicarFiltro(radio.value));
  });

  function aplicarFiltro(categoria) {
    grid.querySelectorAll('.doc-card').forEach((card) => {
      const coincide = categoria === 'todos' || card.dataset.category === categoria;
      card.classList.toggle('is-hidden', !coincide);
    });
  }

  // Agregar un documento subido a la lista 
  function agregarDocumento(file) {
    const categoria = categoriaSelect.value;
    const url = URL.createObjectURL(file);

    const card = document.createElement('div');
    card.className = 'panel doc-card';
    card.dataset.category = categoria;
    card.innerHTML = `
      <div class="doc-card-info">
        <span class="doc-icon"><i class="bi bi-file-earmark-text"></i></span>
        <div>
          <div class="doc-name">${file.name}</div>
          <div class="doc-meta">${CATEGORIA_LABEL[categoria]} · ${formatFechaHoy()} · ${formatBytes(file.size)}</div>
        </div>
      </div>
      <a class="btn-download" href="${url}" download="${file.name}"><i class="bi bi-download"></i> Descargar</a>
    `;

    grid.prepend(card);

    // Respeta el filtro activo al insertar
    const filtroActivo = document.querySelector('input[name="docFilter"]:checked').value;
    card.classList.toggle('is-hidden', filtroActivo !== 'todos' && filtroActivo !== categoria);
  }

  function manejarArchivos(fileList) {
    // TODO: aquí va la subida real al backend / storage.
    Array.from(fileList).forEach(agregarDocumento);
  }

  //Click para seleccionar archivos
  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fileInput.click();
    }
  });

  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) manejarArchivos(fileInput.files);
    fileInput.value = '';
  });

  // ---- Arrastrar y soltar ----
  ['dragenter', 'dragover'].forEach((evt) => {
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.add('is-dragover');
    });
  });

  ['dragleave', 'drop'].forEach((evt) => {
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.remove('is-dragover');
    });
  });

  dropzone.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length) manejarArchivos(e.dataTransfer.files);
  });
});