const JUEGOS = {
  HEAD_BREAKER:   { icono: 'bi-puzzle-fill',         carpeta: 'headbreaker', desc: 'Arma rompecabezas sencillos. Hay desde fácil, medio o difícil, y entre más rápido, más puntos. Libera tu estrés' },
  SPACE_DEFENDER: { icono: 'bi-rocket-takeoff-fill', carpeta: 'spacedefender',          desc: 'Defiende la nave disparando a los aliens oleada tras oleada. Cuando destruyas a un alien morado responde una pregunta del kiosco para recuperar vida.' },
  BREWSTACK:      { icono: 'bi-cup-hot-fill',        carpeta: 'brewstack',   desc: 'Apila bloques para construir la torre más alta: antes de cada bloque, responde una pregunta de trivia.' },
  ATLAS_EXPRESS:  { icono: 'bi-train-front-fill',    carpeta: 'atlasexpress',          desc: 'Atiende a los tripulantes y arrastra el documento de cada uno a su carpeta: Recursos Humanos, Finanzas u Operaciones.' },
  OPTIC_PAYMENT:  { icono: 'bi-eye-fill',            carpeta: 'orbitpayment', desc: 'Salta entre plataformas espaciales, junta monedas y documentos y responde el quiz para pasar de nivel.' }
};

const ESTADO_TURNO = {
  JUGADO:     { texto: 'Jugado',     icono: 'bi-check-circle-fill', clase: 'is-jugado' },
  DISPONIBLE: { texto: 'Disponible', icono: 'bi-play-circle-fill',  clase: 'is-disponible' },
  PROXIMO:    { texto: 'Próximo',    icono: 'bi-clock',             clase: 'is-proximo' },
  AGOTADO:    { texto: 'Sin tiempo', icono: 'bi-hourglass-bottom', clase: 'is-perdido' },
  PERDIDO:    { texto: 'Ya pasó',    icono: 'bi-dash-circle',       clase: 'is-perdido' }
};

document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();
  let juegoTurnos = 'HEAD_BREAKER';
  let jugando = null;

  const $ = (id) => document.getElementById(id);

  function alerta(texto) {
    $('alertaJuegos').textContent = texto;
    $('alertaJuegos').classList.toggle('d-none', !texto);
  }

  let toastTimer;
  function toast(html) {
    const t = $('toast');
    t.innerHTML = html;
    t.classList.remove('d-none');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add('d-none'), 5000);
  }

  async function cargarSaldo() {
    try {
      const s = await api(`/api/usuarios/${usuario}/saldo`);
      $('saldo').textContent = Number(s.saldo || 0).toLocaleString('es-MX');
    } catch (e) {
      $('saldo').textContent = '—';
    }
  }

  function pintarSiguiente(turnos) {
    const box = $('turnoSiguiente');
    if (!box) return;
    const disp = turnos.find((t) => t.estado === 'DISPONIBLE');
    if (disp) { box.className = 'mj-siguiente is-ahora'; box.innerHTML = `<i class="bi bi-play-circle-fill"></i><div><b>¡Turno de ${esc(disp.nombre.toLowerCase())} disponible!</b><span>Juega hasta las ${esc(disp.hasta)}.</span></div>`; return; }
    const sig = turnos.find((t) => t.estado === 'PROXIMO');
    if (sig) { box.className = 'mj-siguiente'; box.innerHTML = `<i class="bi bi-alarm-fill"></i><div><b>Tu siguiente turno: ${esc(sig.nombre)}</b><span>Vuelve a las ${esc(sig.desde)} y juega hasta las ${esc(sig.hasta)}.</span></div>`; return; }
    const primero = turnos[0];
    box.className = 'mj-siguiente is-manana';
    box.innerHTML = `<i class="bi bi-moon-stars-fill"></i><div><b>¡Terminaste tus turnos de hoy!</b><span>Vuelve mañana${primero ? ' desde las ' + esc(primero.desde) : ''} para seguir ganando monedas.</span></div>`;
  }

  async function cargarTurnos() {
    const info = JUEGOS[juegoTurnos] || {};
    $('turnosJuego').textContent = info.nombre || juegoTurnos;
    try {
      const r = await api(`/api/usuarios/${usuario}/turnos?juego=${juegoTurnos}`);
      $('turnosMensaje').textContent = r.resumen ? r.resumen.mensaje : '';
      pintarSiguiente(r.turnos || []);
      $('turnosLista').innerHTML = (r.turnos || []).map((t) => {
        const e = ESTADO_TURNO[t.estado] || ESTADO_TURNO.PROXIMO;
        return `
          <div class="mj-turno ${e.clase}">
            <div class="mj-turno-nombre">${esc(t.nombre)}</div>
            <div class="mj-turno-hora">${esc(t.desde)} – ${esc(t.hasta)}</div>
            <div class="mj-turno-estado"><i class="bi ${e.icono}"></i> ${e.texto}</div>
          </div>`;
      }).join('');
    } catch (e) {
      $('turnosMensaje').textContent = e.message;
      $('turnosLista').innerHTML = '';
    }
  }

  async function cargarJuegos() {
    try {
      const juegos = await api('/api/minijuegos');
      juegos.forEach((j) => { if (JUEGOS[j.clave]) JUEGOS[j.clave].nombre = j.nombre; });

      juegos.sort((a, b) => Number(!!(JUEGOS[b.clave] || {}).carpeta) - Number(!!(JUEGOS[a.clave] || {}).carpeta));

      $('juegos').innerHTML = juegos.map((j) => {
        const info = JUEGOS[j.clave] || { icono: 'bi-controller', desc: '' };
        const listo = !!info.carpeta;
        return `
          <div class="panel mj-card ${listo ? '' : 'is-pronto'}">
            <div class="mj-card-top">
              <span class="mj-card-icono"><i class="bi ${info.icono}"></i></span>
              ${listo ? '<span class="mj-pill">Disponible</span>' : '<span class="mj-pill is-pronto">Próximamente</span>'}
            </div>
            <div class="mj-card-nombre">${esc(j.nombre)}</div>
            <div class="mj-card-desc">${esc(info.desc)}</div>
            ${listo ? `<div class="mj-card-record" id="record-${j.clave}"></div>` : ''}
            <button type="button" class="btn ${listo ? 'btn-primary' : 'btn-light'} w-100 fw-semibold mt-auto"
                    data-jugar="${j.clave}" ${listo ? '' : 'disabled'}>
              ${listo ? '<i class="bi bi-play-fill"></i> Jugar' : '<i class="bi bi-hourglass-split"></i> Próximamente'}
            </button>
          </div>`;
      }).join('');

      juegos.filter((j) => (JUEGOS[j.clave] || {}).carpeta).forEach((j) => cargarRecord(j.clave));
      cargarTurnos();
    } catch (e) {
      $('juegos').innerHTML = '';
      alerta(e.message);
    }
  }

  async function cargarRecord(clave) {
    const el = $(`record-${clave}`);
    if (!el) return;
    try {
      const lb = await api(`/api/minijuegos/${clave}/leaderboard?usuario=${usuario}`);
      const mp = lb.miPosicion;
      el.innerHTML = mp && mp.mi_posicion > 0
        ? `<i class="bi bi-trophy-fill"></i> Tu mejor: <strong>${Number(mp.mi_mejor_puntaje).toLocaleString('es-MX')} pts</strong> · lugar ${mp.mi_posicion}`
        : '<i class="bi bi-trophy"></i> Aún no tienes partidas';
    } catch (e) {
      el.textContent = '';
    }
  }

  function abrirJuego(clave) {
    const info = JUEGOS[clave];
    if (!info || !info.carpeta) return;

    jugando = clave;
    juegoTurnos = clave;
    cargarTurnos();

    $('playerIcono').className = `bi ${info.icono}`;
    $('playerNombre').textContent = info.nombre || clave;

    const url = `${API_URL}/juegos/${info.carpeta}/index.html?usuario=${usuario}`;
    $('frame').innerHTML = `<iframe src="${url}" title="${esc(info.nombre || clave)}" allow="fullscreen; autoplay"></iframe>`;
    const ifr = $('frame').querySelector('iframe');
    if (ifr) { ifr.addEventListener('load', () => { try { ifr.focus(); ifr.contentWindow.focus(); } catch (e) {} }); }
    $('player').classList.remove('d-none');
    $('player').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function cerrarJuego() {
    if (!jugando) return;
    if (!confirm('¿Cerrar el juego? Si estás a media partida, ese turno se pierde.')) return;
    jugando = null;
    $('frame').innerHTML = '';
    $('player').classList.add('d-none');
    cargarSaldo();
    cargarTurnos();
  }

  $('juegos').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-jugar]');
    if (b) abrirJuego(b.dataset.jugar);
  });

  $('btnCerrar').addEventListener('click', cerrarJuego);

  $('btnPantalla').addEventListener('click', () => {
    const f = $('frame').querySelector('iframe');
    if (f && f.requestFullscreen) f.requestFullscreen();
  });

  window.addEventListener('message', (e) => {
    const m = e.data;
    if (!m || m.fuente !== 'kiosko-juego') return;
    let datos = {};
    try { datos = JSON.parse(m.datos || '{}'); } catch (err) {  }

    if (m.tipo === 'turno') {
      cargarTurnos();
    } else if (m.tipo === 'partida') {
      cargarSaldo();
      cargarTurnos();
      if (jugando) cargarRecord(jugando);
      if (datos.monedas > 0) {
        toast(`<i class="bi bi-coin"></i> +${datos.monedas} monedas · ${Number(datos.puntaje).toLocaleString('es-MX')} pts${datos.record ? ' · <strong>¡Nuevo récord!</strong>' : ''}`);
      }
    }
  });

  cargarSaldo();
  cargarJuegos();
  setInterval(cargarTurnos, 60000);
});
