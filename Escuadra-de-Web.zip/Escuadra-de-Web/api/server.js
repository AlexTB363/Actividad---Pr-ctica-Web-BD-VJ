require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { sql, getPool } = require('./db');
const { sendCode } = require('./mailer');

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  console.error('Falta JWT_SECRET en el archivo .env');
  process.exit(1);
}
const SESSION_MIN = Number(process.env.SESSION_MINUTES || 5);
const CODE_MIN = 5;
const BYPASS_2FA = process.env.DEV_2FA_BYPASS === 'true';
const IS_PROD = process.env.NODE_ENV === 'production';
const HTML_DIR = path.join(__dirname, '..');

const app = express();
app.use(express.json());
app.use(cookieParser());

// ---------- Helpers ----------
const cookieOpts = (minutes) => ({
  httpOnly: true,
  sameSite: 'lax',
  secure: IS_PROD,
  path: '/',
  maxAge: minutes * 60 * 1000
});

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

function readToken(req, cookieName, purpose) {
  const t = req.cookies[cookieName];
  if (!t) return null;
  try {
    const payload = jwt.verify(t, SECRET);
    return payload.purpose === purpose ? payload : null;
  } catch {
    return null;
  }
}

// Soporta contraseñas ya hasheadas (bcrypt) y las de texto plano que tienes hoy.
// Si la contraseña estaba en texto plano y es correcta, la convierte a hash.
async function checkPassword(pool, user, plain) {
  const stored = String(user.contrasena || '');
  if (stored.startsWith('$2')) {
    return bcrypt.compare(plain, stored);
  }
  const ok = crypto.timingSafeEqual(Buffer.from(sha(stored)), Buffer.from(sha(plain)));
  if (ok) {
    try {
      const hash = await bcrypt.hash(plain, 10);
      await pool.request()
        .input('id', sql.Int, user.id)
        .input('hash', sql.NVarChar(255), hash)
        .query('UPDATE USUARIOS SET contrasena = @hash WHERE id = @id');
    } catch (e) {
      console.warn('No se pudo actualizar a hash (¿la columna contrasena es muy corta?):', e.message);
    }
  }
  return ok;
}

// código 2FA pendiente: userId -> { hash, expires, attempts }
const pendingCodes = new Map();

// ---------- Rate limits ----------
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  message: { error: 'Demasiados intentos. Espera unos minutos.' }
});

// ---------- API ----------
app.post('/api/login', loginLimiter, async (req, res) => {
  const correo = String(req.body.correo || '').trim().toLowerCase();
  const contrasena = String(req.body.contrasena || '');
  if (!correo || !contrasena) {
    return res.status(400).json({ error: 'Escribe tu correo y contraseña.' });
  }

  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('correo', sql.NVarChar(255), correo)
      .query('SELECT id, nombre, correo, contrasena FROM USUARIOS WHERE LOWER(correo) = @correo');

    const user = result.recordset[0];
    const ok = user ? await checkPassword(pool, user, contrasena) : false;
    if (!ok) {
      return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
    }

    const code = String(crypto.randomInt(100000, 1000000));
    pendingCodes.set(user.id, { hash: sha(code), expires: Date.now() + CODE_MIN * 60 * 1000, attempts: 0 });

    try {
      await sendCode(user.correo, code);
    } catch (e) {
      console.error('Error enviando correo:', e.message);
      return res.status(500).json({ error: 'No se pudo enviar el código de verificación.' });
    }

    const pending = jwt.sign({ sub: user.id, purpose: 'pending' }, SECRET, { expiresIn: `${CODE_MIN}m` });
    res.cookie('pending', pending, cookieOpts(CODE_MIN));
    res.json({ ok: true, requiere2fa: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error del servidor.' });
  }
});

app.post('/api/verify', loginLimiter, async (req, res) => {
  const pending = readToken(req, 'pending', 'pending');
  if (!pending) {
    return res.status(401).json({ error: 'Tu verificación venció. Inicia sesión de nuevo.' });
  }

  const codigo = String(req.body.codigo || '').trim();
  const entry = pendingCodes.get(pending.sub);
  if (!entry || entry.expires < Date.now()) {
    pendingCodes.delete(pending.sub);
    return res.status(401).json({ error: 'El código venció. Inicia sesión de nuevo.' });
  }

  const valid = BYPASS_2FA ? codigo.length > 0 : sha(codigo) === entry.hash;
  if (!valid) {
    entry.attempts += 1;
    if (entry.attempts >= 5) {
      pendingCodes.delete(pending.sub);
      return res.status(429).json({ error: 'Demasiados intentos. Inicia sesión de nuevo.' });
    }
    return res.status(401).json({ error: 'Código incorrecto.' });
  }

  pendingCodes.delete(pending.sub);

  try {
    const pool = await getPool();
    const r = await pool.request()
      .input('id', sql.Int, pending.sub)
      .query('SELECT id, nombre, correo FROM USUARIOS WHERE id = @id');
    const user = r.recordset[0];
    if (!user) return res.status(401).json({ error: 'Usuario no encontrado.' });

    const session = jwt.sign(
      { sub: user.id, nombre: user.nombre, correo: user.correo, purpose: 'session' },
      SECRET,
      { expiresIn: `${SESSION_MIN}m` }
    );
    res.clearCookie('pending', { path: '/' });
    res.cookie('session', session, cookieOpts(SESSION_MIN));
    res.json({ ok: true, redirect: 'dashboard.html' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error del servidor.' });
  }
});

app.get('/api/me', (req, res) => {
  res.set('Cache-Control', 'no-store');
  const s = readToken(req, 'session', 'session');
  if (!s) return res.status(401).json({ error: 'No autenticado.' });
  res.json({ id: s.sub, nombre: s.nombre, correo: s.correo, expiraEn: s.exp * 1000 });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('session', { path: '/' });
  res.clearCookie('pending', { path: '/' });
  res.json({ ok: true });
});

// Middleware para tus futuras rutas protegidas de la API:
//   app.get('/api/empleados', requireSession, (req, res) => { ... })
function requireSession(req, res, next) {
  const s = readToken(req, 'session', 'session');
  if (!s) return res.status(401).json({ error: 'No autenticado.' });
  req.user = s;
  next();
}
module.exports = { requireSession };

app.use((req, res, next) => {
  const p = req.path.toLowerCase();
  if (p.startsWith('/api/') || p.startsWith('/node_modules') || p.startsWith('/.git') || p.endsWith('package.json') || p.endsWith('package-lock.json')) {
    return res.status(404).send('Not found');
  }
  next();
});

// ---------- Guardia de páginas HTML ----------
app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  const p = req.path.toLowerCase();
  if (!(p === '/' || p.endsWith('.html'))) return next();

  res.set('Cache-Control', 'no-store'); // evita que el botón "atrás" muestre páginas protegidas

  if (p === '/' || p === '/index.html') return next();

  if (p === '/verify.html') {
    if (readToken(req, 'pending', 'pending') || readToken(req, 'session', 'session')) return next();
    return res.redirect('/index.html');
  }

  if (readToken(req, 'session', 'session')) return next();
  res.redirect('/index.html');
});

app.use(express.static(HTML_DIR, { index: 'index.html' }));

app.listen(PORT, () => {
  console.log(`Servidor listo en http://localhost:${PORT}`);
  console.log(`Sesión: ${SESSION_MIN} min | 2FA bypass: ${BYPASS_2FA ? 'SÍ (solo pruebas)' : 'no'}`);
});