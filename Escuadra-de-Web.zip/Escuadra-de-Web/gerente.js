document.addEventListener('DOMContentLoaded', () => {
  if (window.VacCalendario) window.VacCalendario.initBotones(document);


  const nombreEmpresa = document.getElementById('nombreEmpresa');
  const inicialesLogo = document.getElementById('inicialesLogo');
  const previewNombre = document.getElementById('previewNombre');
  const previewLogo = document.getElementById('previewLogo');

  const colorPrincipal = document.getElementById('colorPrincipal');
  const colorPrincipalHex = document.getElementById('colorPrincipalHex');
  const colorAcento = document.getElementById('colorAcento');
  const colorAcentoHex = document.getElementById('colorAcentoHex');

  const paletteOptions = document.querySelectorAll('.palette-option');
  const HEX_RE = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;

  const DEFAULTS = { primary: '#3f51e8', accent: '#eef1fb' };


  function aplicarColores(primary, accent) {
    document.documentElement.style.setProperty('--color-primary', primary);
    document.documentElement.style.setProperty('--color-bg-page', accent);
    colorPrincipal.value = primary;
    colorPrincipalHex.value = primary;
    colorAcento.value = accent;
    colorAcentoHex.value = accent;
  }

  function seleccionarPaleta(option) {
    paletteOptions.forEach((o) => o.classList.remove('is-selected'));
    option.classList.add('is-selected');
    const input = option.querySelector('input');
    input.checked = true;
    aplicarColores(input.dataset.primary, input.dataset.accent);
  }

  paletteOptions.forEach((option) => {
    option.addEventListener('click', () => seleccionarPaleta(option));
  });


  function usarColorPersonalizado() {
    paletteOptions.forEach((o) => o.classList.remove('is-selected'));
  }

  colorPrincipal.addEventListener('input', () => {
    aplicarColores(colorPrincipal.value, colorAcento.value);
    usarColorPersonalizado();
  });
  colorAcento.addEventListener('input', () => {
    aplicarColores(colorPrincipal.value, colorAcento.value);
    usarColorPersonalizado();
  });

  [colorPrincipalHex, colorAcentoHex].forEach((input) => {
    input.addEventListener('change', () => {
      if (!HEX_RE.test(input.value)) return; 
      aplicarColores(colorPrincipalHex.value, colorAcentoHex.value);
      usarColorPersonalizado();
    });
  });

  nombreEmpresa.addEventListener('input', () => {
    previewNombre.textContent = nombreEmpresa.value || 'People Tech';
  });
  inicialesLogo.addEventListener('input', () => {
    previewLogo.textContent = (inicialesLogo.value || 'PT').toUpperCase();
  });

  document.getElementById('btnRestaurar').addEventListener('click', () => {
    nombreEmpresa.value = 'People Tech';
    inicialesLogo.value = 'PT';
    previewNombre.textContent = 'People Tech';
    previewLogo.textContent = 'PT';
    seleccionarPaleta(paletteOptions[0]);
    aplicarColores(DEFAULTS.primary, DEFAULTS.accent);
  });



  // Solicitudes de vacaciones 
  const lista = document.getElementById('solicitudesList');
  const pendingCount = document.getElementById('pendingCount');

  function actualizarContadorPendientes() {
    const n = lista.querySelectorAll('.list-group-item[data-status="pendiente"]').length;
    pendingCount.textContent = `${n} pendiente(s)`;
    const quickBadge = document.getElementById('quickNavPendingBadge');
    if (quickBadge) {
      quickBadge.textContent = n;
      quickBadge.style.display = n > 0 ? 'inline-block' : 'none';
    }
  }

  function renderAcciones(item, estado) {
    const actions = item.querySelector('.request-actions');
    const badges = {
      pendiente: '<span class="badge-status badge-pending">Pendiente</span>',
      aprobada: '<span class="badge-status badge-approved">Aprobada</span>',
      rechazada: '<span class="badge-status badge-rejected">Rechazada</span>',
    };
    const botones = {
      pendiente: '<button type="button" class="btn-approve"><i class="bi bi-check-lg"></i> Aprobar</button><button type="button" class="btn-reject"><i class="bi bi-x-lg"></i> Rechazar</button>',
      aprobada: '<button type="button" class="btn-reject"><i class="bi bi-x-lg"></i> Rechazar</button>',
      rechazada: '<button type="button" class="btn-approve"><i class="bi bi-check-lg"></i> Aprobar</button>',
    };
    actions.innerHTML = badges[estado] + botones[estado];
  }

  lista.addEventListener('click', (e) => {
    const item = e.target.closest('.list-group-item');
    if (!item) return;

    if (e.target.closest('.btn-approve')) {
      item.dataset.status = 'aprobada';
      renderAcciones(item, 'aprobada');
    } else if (e.target.closest('.btn-reject')) {
      item.dataset.status = 'rechazada';
      renderAcciones(item, 'rechazada');
    } else {
      return;
    }

    actualizarContadorPendientes();
  });

  actualizarContadorPendientes();

  // ==========================================
  // Navegación Rápida por Secciones
  // ==========================================
  const quickNavButtons = document.querySelectorAll('.btn-quick-nav');
  quickNavButtons.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const targetSelector = btn.getAttribute('data-target');
      const targetElement = document.querySelector(targetSelector);
      if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        quickNavButtons.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
      }
    });
  });

  // ==========================================
  // Gestión de Eventos y Noticias Comunitarias
  // ==========================================
  if (window.EventosManager) {
    const selectEvento = document.getElementById('selectEvento');
    const contenedorSelect = document.getElementById('contenedorSelectEvento');
    const formEvento = document.getElementById('formEvento');
    const inputCategoria = document.getElementById('eventoCategoria');
    const inputTitulo = document.getElementById('eventoTitulo');
    const inputFecha = document.getElementById('eventoFecha');
    const inputHora = document.getElementById('eventoHora');
    const inputLugar = document.getElementById('eventoLugar');
    const inputMenu = document.getElementById('eventoMenu');
    const inputDesc = document.getElementById('eventoDescripcion');
    const inputActivo = document.getElementById('eventoActivo');
    const btnSubmit = document.getElementById('btnSubmitEvento');
    const btnRestaurar = document.getElementById('btnRestaurarEvento');
    const btnCrear = document.getElementById('btnCrearNoticia');
    const btnCancelarCrear = document.getElementById('btnCancelarCrear');
    const btnEliminar = document.getElementById('btnEliminarEvento');
    const textoModo = document.getElementById('textoModo');
    const alerta = document.getElementById('alertaEvento');

    // Elementos de la vista previa
    const prevBadge = document.getElementById('previewBadge');
    const prevFecha = document.getElementById('previewFecha');
    const prevTitulo = document.getElementById('previewTitulo');
    const prevDesc = document.getElementById('previewDescripcion');
    const prevHora = document.getElementById('previewHora');
    const prevLugar = document.getElementById('previewLugar');
    const prevMenu = document.getElementById('previewMenu');
    const prevInfoBox = document.getElementById('previewInfoBox');
    const prevCard = document.getElementById('previewEventoCard');
    const prevReaccionesGroup = document.getElementById('previewReaccionesGroup');

    // Elementos del configurador de reacciones
    const listaReaccionesConfig = document.getElementById('listaReaccionesConfig');
    const btnAgregarReaccion = document.getElementById('btnAgregarReaccion');
    const emojiChips = document.querySelectorAll('.emoji-chip');

    let modoCrear = false;
    let ultimaFilaActiva = null;

    function esc(t) {
      return String(t || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function crearFilaReaccion(reac = {}) {
      const fila = document.createElement('div');
      fila.className = 'reaccion-fila d-flex align-items-center gap-2 p-2 rounded-2 border';
      fila.dataset.id = reac.id || `reac_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

      const emoji = reac.icon || '👍';
      const label = reac.label || '';
      const count = reac.baseCount !== undefined ? reac.baseCount : 10;

      fila.innerHTML = `
        <div style="width: 55px;" class="flex-shrink-0">
          <input type="text" class="form-control form-control-sm text-center reaccion-emoji fs-5 p-1" value="${esc(emoji)}" maxlength="4" placeholder="😀" title="Emoji de la reacción" required>
        </div>
        <div class="flex-grow-1">
          <input type="text" class="form-control form-control-sm reaccion-label fw-semibold" value="${esc(label)}" placeholder="Texto que determina la reacción (ej. ¡Quiero café!)" required>
        </div>
        <div style="width: 80px;" class="flex-shrink-0">
          <div class="input-group input-group-sm">
            <span class="input-group-text px-1 text-muted" title="Conteo base"><i class="bi bi-people" style="font-size: 11px;"></i></span>
            <input type="number" class="form-control text-center reaccion-count px-1" value="${count}" min="0" max="9999" title="Conteo inicial">
          </div>
        </div>
        <button type="button" class="btn btn-sm btn-outline-danger btn-eliminar-reaccion px-2 flex-shrink-0" title="Eliminar reacción">
          <i class="bi bi-trash3"></i>
        </button>
      `;

      const emojiInput = fila.querySelector('.reaccion-emoji');
      const labelInput = fila.querySelector('.reaccion-label');
      const countInput = fila.querySelector('.reaccion-count');
      const btnEliminar = fila.querySelector('.btn-eliminar-reaccion');

      [emojiInput, labelInput, countInput].forEach((inp) => {
        inp.addEventListener('input', () => {
          actualizarVistaPreviaReacciones();
        });
      });

      btnEliminar.addEventListener('click', () => {
        if (!listaReaccionesConfig) return;
        const total = listaReaccionesConfig.querySelectorAll('.reaccion-fila').length;
        if (total <= 1) {
          alert('Debes mantener al menos 1 botón de reacción configurado para la noticia.');
          return;
        }
        fila.remove();
        actualizarVistaPreviaReacciones();
      });

      return fila;
    }

    function cargarReaccionesEnEditor(reacciones) {
      if (!listaReaccionesConfig) return;
      listaReaccionesConfig.innerHTML = '';

      const lista = (Array.isArray(reacciones) && reacciones.length > 0)
        ? reacciones
        : [
            { id: 'reac_1', icon: '☕', label: '¡Quiero café!', baseCount: 25 },
            { id: 'reac_2', icon: '🎉', label: '¡Ahí estaré!', baseCount: 18 },
            { id: 'reac_3', icon: '❤️', label: 'Me encanta', baseCount: 12 }
          ];

      lista.forEach((r) => {
        const fila = crearFilaReaccion(r);
        listaReaccionesConfig.appendChild(fila);
      });

      actualizarVistaPreviaReacciones();
    }

    function obtenerReaccionesConfiguradas() {
      if (!listaReaccionesConfig) return [];
      const filas = listaReaccionesConfig.querySelectorAll('.reaccion-fila');
      const resultado = [];

      filas.forEach((fila, idx) => {
        const icon = fila.querySelector('.reaccion-emoji').value.trim() || '👍';
        const label = fila.querySelector('.reaccion-label').value.trim() || `Opción ${idx + 1}`;
        const baseCount = parseInt(fila.querySelector('.reaccion-count').value, 10) || 0;
        const id = fila.dataset.id || `reac_${idx + 1}`;
        resultado.push({ id, icon, label, baseCount });
      });

      return resultado;
    }

    function actualizarVistaPreviaReacciones() {
      if (!prevReaccionesGroup) return;
      const reacs = obtenerReaccionesConfiguradas();

      if (reacs.length === 0) {
        prevReaccionesGroup.innerHTML = '<span class="text-muted small">Sin botones de reacción configurados.</span>';
        return;
      }

      prevReaccionesGroup.innerHTML = reacs.map((r) => `
        <button type="button" class="btn-reaction" style="pointer-events: none; opacity: 0.95;">
          <span class="reaction-icon">${esc(r.icon)}</span>
          <span>${esc(r.label)}</span>
          <span class="reaction-count">${r.baseCount}</span>
        </button>
      `).join('');
    }

    // Monitorear foco en las filas para saber dónde insertar sugerencias de emoji
    if (listaReaccionesConfig) {
      listaReaccionesConfig.addEventListener('focusin', (e) => {
        const fila = e.target.closest('.reaccion-fila');
        if (fila) ultimaFilaActiva = fila;
      });
    }

    // Chips de sugerencia rápida de emojis y textos
    emojiChips.forEach((chip) => {
      chip.addEventListener('click', () => {
        const emoji = chip.getAttribute('data-emoji') || '👍';
        const label = chip.getAttribute('data-label') || '';

        // Si hay una fila enfocada actualmente, actualizarla
        if (ultimaFilaActiva && listaReaccionesConfig && listaReaccionesConfig.contains(ultimaFilaActiva)) {
          const emojiInp = ultimaFilaActiva.querySelector('.reaccion-emoji');
          const labelInp = ultimaFilaActiva.querySelector('.reaccion-label');
          if (emojiInp) emojiInp.value = emoji;
          if (labelInp && (!labelInp.value.trim() || labelInp.value === 'De acuerdo' || labelInp.value === 'Me gusta')) {
            labelInp.value = label;
          }
          actualizarVistaPreviaReacciones();
          return;
        }

        if (!listaReaccionesConfig) return;
        const filas = listaReaccionesConfig.querySelectorAll('.reaccion-fila');

        // Si alguna fila tiene el texto vacío, rellenarla
        for (const f of filas) {
          const labelInp = f.querySelector('.reaccion-label');
          if (labelInp && !labelInp.value.trim()) {
            f.querySelector('.reaccion-emoji').value = emoji;
            labelInp.value = label;
            actualizarVistaPreviaReacciones();
            return;
          }
        }

        // Si hay espacio (< 6), agregar una nueva fila con este emoji y texto
        if (filas.length < 6) {
          const nueva = crearFilaReaccion({
            id: `reac_${Date.now()}`,
            icon: emoji,
            label: label,
            baseCount: 15
          });
          listaReaccionesConfig.appendChild(nueva);
          actualizarVistaPreviaReacciones();
          const inp = nueva.querySelector('.reaccion-label');
          if (inp) inp.focus();
        } else {
          alert('Has alcanzado el límite de 6 botones de reacción. Puedes modificar o eliminar una fila existente.');
        }
      });
    });

    // Botón para agregar una nueva fila de reacción
    if (btnAgregarReaccion) {
      btnAgregarReaccion.addEventListener('click', () => {
        if (!listaReaccionesConfig) return;
        const filas = listaReaccionesConfig.querySelectorAll('.reaccion-fila');
        if (filas.length >= 6) {
          alert('Puedes configurar un máximo de 6 botones de reacción por noticia.');
          return;
        }
        const nueva = crearFilaReaccion({
          id: `reac_${Date.now()}`,
          icon: '👍',
          label: 'De acuerdo',
          baseCount: 10
        });
        listaReaccionesConfig.appendChild(nueva);
        actualizarVistaPreviaReacciones();
        const inp = nueva.querySelector('.reaccion-label');
        if (inp) {
          inp.focus();
          inp.select();
        }
      });
    }

    function poblarSelectorEventos(idSeleccionado) {
      if (!selectEvento) return;
      const eventos = EventosManager.obtenerEventos();
      selectEvento.innerHTML = '';
      eventos.forEach((ev) => {
        const opt = document.createElement('option');
        opt.value = ev.id;
        opt.textContent = ev.titulo || 'Sin título';
        selectEvento.appendChild(opt);
      });

      if (idSeleccionado) {
        selectEvento.value = idSeleccionado;
      } else if (eventos.length > 0) {
        selectEvento.value = eventos[0].id;
      }
    }

    function cargarEventoEnFormulario(id) {
      if (modoCrear) return;
      const evento = EventosManager.obtenerEvento(id);
      if (!evento) return;

      if (inputCategoria) inputCategoria.value = evento.badge || 'Evento de Comunidad';
      inputTitulo.value = evento.titulo || '';
      inputFecha.value = evento.fecha || '';
      inputHora.value = evento.hora || '';
      inputLugar.value = evento.lugar || '';
      inputMenu.value = evento.menu || '';
      inputDesc.value = evento.descripcion || '';
      inputActivo.checked = evento.activo !== false;

      // Cargar los botones de reacción configurados para esta noticia
      cargarReaccionesEnEditor(evento.reacciones);

      // El botón eliminar solo se muestra para eventos personalizados (no los dos iniciales)
      if (btnEliminar) {
        if (id !== 'viernes-cafe' && id !== 'guia-kiosko') {
          btnEliminar.classList.remove('d-none');
        } else {
          btnEliminar.classList.add('d-none');
        }
      }

      actualizarVistaPrevia();
    }

    function entrarModoCrear() {
      modoCrear = true;
      if (textoModo) textoModo.textContent = '✨ Creando nueva noticia o evento';
      if (btnCancelarCrear) btnCancelarCrear.classList.remove('d-none');
      if (contenedorSelect) contenedorSelect.classList.add('d-none');
      if (btnEliminar) btnEliminar.classList.add('d-none');

      // Limpiar campos
      if (inputCategoria) inputCategoria.value = 'Evento de Comunidad';
      inputTitulo.value = '';
      inputFecha.value = 'Próximamente';
      inputHora.value = '10:00 AM – 12:00 PM';
      inputLugar.value = 'Oficinas People Tech';
      inputMenu.value = '';
      inputDesc.value = '';
      inputActivo.checked = true;

      // Cargar reacciones sugeridas por defecto para la nueva noticia
      cargarReaccionesEnEditor([
        { id: 'reac_1', icon: '❤️', label: 'Me encanta', baseCount: 15 },
        { id: 'reac_2', icon: '🎉', label: '¡Ahí estaré!', baseCount: 12 },
        { id: 'reac_3', icon: '👏', label: '¡Excelente!', baseCount: 8 }
      ]);

      if (btnSubmit) {
        btnSubmit.innerHTML = '<i class="bi bi-plus-circle-fill"></i> Publicar Nueva Noticia';
      }

      inputTitulo.focus();
      actualizarVistaPrevia();
    }

    function salirModoCrear() {
      modoCrear = false;
      if (textoModo) textoModo.textContent = 'Editando evento existente';
      if (btnCancelarCrear) btnCancelarCrear.classList.add('d-none');
      if (contenedorSelect) contenedorSelect.classList.remove('d-none');
      if (btnSubmit) {
        btnSubmit.innerHTML = '<i class="bi bi-check2-circle"></i> Guardar y Publicar para Empleados';
      }
      cargarEventoEnFormulario(selectEvento.value);
    }

    function actualizarVistaPrevia() {
      const cat = inputCategoria ? inputCategoria.value : 'Evento de Comunidad';
      const tit = inputTitulo.value || 'Título de la noticia';
      const fec = inputFecha.value || 'Fecha no definida';
      const desc = inputDesc.value || 'Escribe una descripción para verla aquí...';
      const hor = inputHora.value.trim();
      const lug = inputLugar.value.trim();
      const men = inputMenu.value.trim();

      if (prevTitulo) prevTitulo.textContent = tit;
      if (prevFecha) prevFecha.innerHTML = `<i class="bi bi-calendar-event me-1"></i> ${fec}`;
      if (prevDesc) prevDesc.textContent = desc;
      if (prevHora) prevHora.textContent = hor || 'No especificado';
      if (prevLugar) prevLugar.textContent = lug || 'No especificado';
      if (prevMenu) prevMenu.textContent = men || 'No especificado';

      if (prevBadge) {
        if (cat.includes('Guía')) {
          prevBadge.className = 'news-badge badge-guide';
          prevBadge.innerHTML = `<i class="bi bi-compass-fill me-1"></i> ${cat}`;
        } else {
          prevBadge.className = 'news-badge badge-event';
          prevBadge.innerHTML = `<i class="bi bi-megaphone-fill me-1"></i> ${cat}`;
        }
      }

      if (prevCard) {
        if (!inputActivo.checked) {
          prevCard.style.opacity = '0.5';
        } else {
          prevCard.style.opacity = '1';
        }
      }

      if (prevInfoBox) {
        if (!hor && !lug && !men) {
          prevInfoBox.style.display = 'none';
        } else {
          prevInfoBox.style.display = 'block';
        }
      }

      actualizarVistaPreviaReacciones();
    }

    [inputCategoria, inputTitulo, inputFecha, inputHora, inputLugar, inputMenu, inputDesc, inputActivo].forEach((el) => {
      if (el) {
        el.addEventListener('input', actualizarVistaPrevia);
        el.addEventListener('change', actualizarVistaPrevia);
      }
    });

    if (btnCrear) {
      btnCrear.addEventListener('click', () => {
        entrarModoCrear();
        const panel = document.getElementById('panelEventos');
        if (panel) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }

    if (btnCancelarCrear) {
      btnCancelarCrear.addEventListener('click', salirModoCrear);
    }

    if (selectEvento) {
      selectEvento.addEventListener('change', () => {
        cargarEventoEnFormulario(selectEvento.value);
      });
    }

    if (formEvento) {
      formEvento.addEventListener('submit', (e) => {
        e.preventDefault();
        const reacciones = obtenerReaccionesConfiguradas();
        if (reacciones.length === 0) {
          alert('Debes configurar al menos 1 botón de reacción para la noticia.');
          return;
        }

        const datos = {
          badge: inputCategoria ? inputCategoria.value : 'Evento de Comunidad',
          titulo: inputTitulo.value.trim(),
          fecha: inputFecha.value.trim(),
          hora: inputHora.value.trim(),
          lugar: inputLugar.value.trim(),
          menu: inputMenu.value.trim(),
          descripcion: inputDesc.value.trim(),
          activo: inputActivo.checked,
          reacciones: reacciones
        };

        if (modoCrear) {
          const creado = EventosManager.crearNuevoEvento(datos);
          poblarSelectorEventos(creado.id);
          salirModoCrear();
          if (alerta) {
            alerta.classList.remove('d-none');
            const span = alerta.querySelector('span');
            if (span) span.innerHTML = '<strong>¡Nueva noticia creada y publicada!</strong> Ya está disponible para todos los empleados.';
            setTimeout(() => alerta.classList.add('d-none'), 3500);
          }
        } else {
          const id = selectEvento.value;
          EventosManager.actualizarEvento(id, datos);
          poblarSelectorEventos(id);
          if (alerta) {
            alerta.classList.remove('d-none');
            const span = alerta.querySelector('span');
            if (span) span.innerHTML = '<strong>¡Cambios guardados con éxito!</strong> Los empleados verán los cambios actualizados.';
            setTimeout(() => alerta.classList.add('d-none'), 3500);
          }
        }
      });
    }

    if (btnEliminar) {
      btnEliminar.addEventListener('click', () => {
        const id = selectEvento.value;
        if (confirm('¿Estás seguro de que deseas eliminar esta noticia? Dejará de aparecer en la página de los empleados.')) {
          EventosManager.eliminarEvento(id);
          poblarSelectorEventos();
          cargarEventoEnFormulario(selectEvento.value);
          if (alerta) {
            alerta.classList.remove('d-none');
            const span = alerta.querySelector('span');
            if (span) span.innerHTML = '<strong>Noticia eliminada.</strong> Ya no aparecerá para los empleados.';
            setTimeout(() => alerta.classList.add('d-none'), 3000);
          }
        }
      });
    }

    if (btnRestaurar) {
      btnRestaurar.addEventListener('click', () => {
        if (confirm('¿Deseas restaurar todas las noticias a los valores iniciales predeterminados?')) {
          EventosManager.restablecerEventos();
          poblarSelectorEventos();
          cargarEventoEnFormulario(selectEvento.value);
          if (alerta) {
            alerta.classList.remove('d-none');
            const span = alerta.querySelector('span');
            if (span) span.textContent = 'Valores predeterminados restaurados exitosamente.';
            setTimeout(() => alerta.classList.add('d-none'), 3000);
          }
        }
      });
    }

    poblarSelectorEventos();
    cargarEventoEnFormulario(selectEvento.value);
  }
});