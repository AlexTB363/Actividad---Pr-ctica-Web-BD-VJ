const RAREZA = {
  Comun:      { texto: 'Común',      clase: 'shop-rarity-comun' },
  Raro:       { texto: 'Raro',       clase: 'shop-rarity-raro' },
  Epico:      { texto: 'Épico',      clase: 'shop-rarity-epico' },
  Legendario: { texto: 'Legendario', clase: 'shop-rarity-legendario' }
};

document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();
  const saldoEl = document.getElementById('saldoPuntos');
  const coleccionEl = document.getElementById('coleccionCount');
  const alertBox = document.getElementById('shopAlert');
  const grid = document.getElementById('shopGrid');

  let saldo = 0;

  const mostrarAviso = (msg, tipo = 'danger') => {
    alertBox.className = `alert alert-${tipo} mb-4`;
    alertBox.textContent = msg;
  };
  const ocultarAviso = () => alertBox.classList.add('d-none');

  const pts = (n) => Number(n).toLocaleString('es-MX');

  async function cargar() {
    try {
      const t = await api(`/api/usuarios/${usuario}/tienda`);
      saldo = Number(t.saldo || 0);
      saldoEl.textContent = pts(saldo);
      coleccionEl.textContent = `${t.coleccion} personaje(s) en tu colección`;

      grid.innerHTML = t.personajes.map((p) => {
        const r = RAREZA[p.rareza] || RAREZA.Comun;
        let accion;
        if (p.tiene) {
          accion = '<span class="shop-action is-owned"><i class="bi bi-check-lg"></i> En tu colección</span>';
        } else if (saldo >= p.costo) {
          accion = `<button type="button" class="shop-action is-locked" data-id="${p.id_personaje}" data-cost="${p.costo}" data-nombre="${esc(p.nombre)}">
                      <i class="bi bi-bag-check"></i> Canjear · ${pts(p.costo)} pts</button>`;
        } else {
          accion = `<button type="button" class="shop-action is-locked" data-id="${p.id_personaje}" data-cost="${p.costo}" data-nombre="${esc(p.nombre)}">
                      <i class="bi bi-lock"></i> Canjear · ${pts(p.costo)} pts</button>`;
        }
        return `
          <div class="panel shop-card">
            <div class="shop-card-top">
              <span class="shop-icon">${esc(p.icono)}</span>
              <span class="shop-rarity ${r.clase}">${r.texto}</span>
            </div>
            <div class="shop-name">${esc(p.nombre)}</div>
            <div class="shop-desc">${esc(p.descripcion)}</div>
            ${accion}
          </div>`;
      }).join('');
    } catch (e) {
      grid.innerHTML = '';
      mostrarAviso(e.message);
    }
  }

  grid.addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-id]');
    if (!btn) return;

    const costo = Number(btn.dataset.cost);
    if (saldo < costo) {
      mostrarAviso(`Te faltan ${pts(costo - saldo)} pts para canjear este personaje. Juega en Mini Juegos para ganar más.`);
      return;
    }

    ocultarAviso();
    btn.disabled = true;
    try {
      await api('/api/tienda/canjes', jsonBody('POST', { usuario, personaje: Number(btn.dataset.id) }));
      mostrarAviso(`¡Listo! ${btn.dataset.nombre} ya está en tu colección.`, 'success');
      cargar();
    } catch (err) {
      mostrarAviso(err.message);
      btn.disabled = false;
    }
  });

  cargar();
});
