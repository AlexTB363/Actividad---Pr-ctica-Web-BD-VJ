// Manejo de Reacciones y Persistencia en Noticias Comunitarias
(function () {
  const STORAGE_KEY = 'peopletech_news_reactions';

  function obtenerReaccionesGuardadas() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    } catch (e) {
      return {};
    }
  }

  function guardarReacciones(datos) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(datos));
    } catch (e) {
      console.error('No se pudo guardar la reacción en localStorage', e);
    }
  }

  function inicializarReacciones() {
    const reacciones = obtenerReaccionesGuardadas();

    document.querySelectorAll('.btn-reaction').forEach((boton) => {
      const newsId = boton.getAttribute('data-news-id');
      const reaction = boton.getAttribute('data-reaction');
      const countEl = boton.querySelector('.reaction-count');
      const baseCount = parseInt(boton.getAttribute('data-base-count') || countEl.textContent || '0', 10);
      boton.setAttribute('data-base-count', baseCount);

      const key = `${newsId}_${reaction}`;
      const yaReacciono = Boolean(reacciones[key]);

      if (yaReacciono) {
        boton.classList.add('active');
        countEl.textContent = baseCount + 1;
      } else {
        boton.classList.remove('active');
        countEl.textContent = baseCount;
      }

      boton.addEventListener('click', () => {
        const estadoActual = obtenerReaccionesGuardadas();
        const estaActivo = boton.classList.contains('active');
        const countSpan = boton.querySelector('.reaction-count');
        const base = parseInt(boton.getAttribute('data-base-count'), 10);

        if (estaActivo) {
          // Quitar reacción
          boton.classList.remove('active');
          countSpan.textContent = base;
          delete estadoActual[key];
        } else {
          // Agregar reacción
          boton.classList.add('active');
          countSpan.textContent = base + 1;
          estadoActual[key] = true;

          // Animación ligera de pulso
          boton.animate([
            { transform: 'scale(1)' },
            { transform: 'scale(1.18)' },
            { transform: 'scale(1)' }
          ], { duration: 250, easing: 'ease-out' });
        }

        guardarReacciones(estadoActual);
      });
    });
  }

  function esc(t) {
    return String(t || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function cargarDatosEventos() {
    if (!window.EventosManager) return;

    // Noticia fija: Viernes de café
    const cafe = EventosManager.obtenerEvento('viernes-cafe');
    if (cafe) {
      const card = document.getElementById('cardViernesCafe');
      const titulo = document.getElementById('cafeTitulo');
      const fecha = document.getElementById('cafeFecha');
      const desc = document.getElementById('cafeDescripcion');
      const hora = document.getElementById('cafeHora');
      const lugar = document.getElementById('cafeLugar');
      const menu = document.getElementById('cafeMenu');

      if (card) {
        card.style.display = cafe.activo === false ? 'none' : 'block';
      }
      if (titulo && cafe.titulo) titulo.textContent = cafe.titulo;
      if (fecha && cafe.fecha) fecha.innerHTML = `<i class="bi bi-calendar-event me-1"></i> ${cafe.fecha}`;
      if (desc && cafe.descripcion) desc.textContent = cafe.descripcion;
      if (hora && cafe.hora) hora.textContent = cafe.hora;
      if (lugar && cafe.lugar) lugar.textContent = cafe.lugar;
      if (menu && cafe.menu) menu.textContent = cafe.menu;

      if (cafe.reacciones && cafe.reacciones.length > 0) {
        const reacContainer = document.getElementById('reaccionesViernesCafe');
        if (reacContainer) {
          reacContainer.innerHTML = cafe.reacciones.map((r) => `
            <button type="button" class="btn-reaction btn-reaction-coffee" data-news-id="viernes-cafe" data-reaction="${r.id}" data-base-count="${r.baseCount || 10}">
              <span class="reaction-icon">${r.icon || '☕'}</span>
              <span>${esc(r.label || 'Reaccionar')}</span>
              <span class="reaction-count">${r.baseCount || 10}</span>
            </button>
          `).join('');
        }
      }
    }

    // Noticia fija: Guía del Kiosko
    const guia = EventosManager.obtenerEvento('guia-kiosko');
    if (guia && guia.reacciones && guia.reacciones.length > 0) {
      const reacGuia = document.getElementById('reaccionesGuiaKiosko');
      if (reacGuia) {
        reacGuia.innerHTML = guia.reacciones.map((r) => `
          <button type="button" class="btn-reaction" data-news-id="guia-kiosko" data-reaction="${r.id}" data-base-count="${r.baseCount || 10}">
            <span class="reaction-icon">${r.icon || '💡'}</span>
            <span>${esc(r.label || 'Reaccionar')}</span>
            <span class="reaction-count">${r.baseCount || 10}</span>
          </button>
        `).join('');
      }
    }

    // Renderizar noticias dinámicas creadas por gerentes
    const contenedor = document.getElementById('contenedorNoticiasPersonalizadas');
    if (contenedor) {
      contenedor.innerHTML = '';
      const todos = EventosManager.obtenerEventos();
      const personalizados = todos.filter((ev) => ev.id !== 'viernes-cafe' && ev.id !== 'guia-kiosko' && ev.activo !== false);

      personalizados.forEach((ev) => {
        const tieneDetalles = Boolean(ev.hora || ev.lugar || ev.menu);
        const article = document.createElement('article');
        article.className = 'news-card news-card-highlight';
        article.id = `card-${ev.id}`;

        let infoBoxHtml = '';
        if (tieneDetalles) {
          infoBoxHtml = `
            <div class="event-info-box mb-3">
              ${ev.hora ? `
                <div class="event-info-item">
                  <div class="event-info-icon"><i class="bi bi-alarm-fill"></i></div>
                  <div class="event-info-text"><strong>Horario</strong><span>${esc(ev.hora)}</span></div>
                </div>` : ''}
              ${ev.lugar ? `
                <div class="event-info-item">
                  <div class="event-info-icon"><i class="bi bi-geo-alt-fill"></i></div>
                  <div class="event-info-text"><strong>Lugar</strong><span>${esc(ev.lugar)}</span></div>
                </div>` : ''}
              ${ev.menu ? `
                <div class="event-info-item">
                  <div class="event-info-icon"><i class="bi bi-info-circle-fill"></i></div>
                  <div class="event-info-text"><strong>Detalles</strong><span>${esc(ev.menu)}</span></div>
                </div>` : ''}
            </div>`;
        }

        const reacciones = ev.reacciones || [
          { id: 'like', icon: '❤️', label: 'Me gusta', baseCount: 15 },
          { id: 'genial', icon: '🎉', label: 'Genial', baseCount: 10 }
        ];

        const reaccionesHtml = reacciones.map((r) => `
          <button type="button" class="btn-reaction" data-news-id="${ev.id}" data-reaction="${r.id}" data-base-count="${r.baseCount}">
            <span class="reaction-icon">${r.icon}</span>
            <span>${esc(r.label)}</span>
            <span class="reaction-count">${r.baseCount}</span>
          </button>
        `).join('');

        article.innerHTML = `
          <div class="news-header">
            <div>
              <div class="news-meta">
                <span class="news-badge badge-event">
                  <i class="bi bi-megaphone-fill me-1"></i> ${esc(ev.badge || 'Aviso de Comunidad')}
                </span>
                <span class="news-date">
                  <i class="bi bi-calendar-event me-1"></i> ${esc(ev.fecha || 'Reciente')}
                </span>
              </div>
              <h2 class="news-title">${esc(ev.titulo)}</h2>
            </div>
          </div>

          <p class="news-summary">${esc(ev.descripcion)}</p>
          ${infoBoxHtml}

          <div class="news-footer">
            <div class="reaction-label">
              <i class="bi bi-chat-heart"></i> Reacciona a este aviso:
            </div>
            <div class="reactions-group">
              ${reaccionesHtml}
            </div>
          </div>
        `;

        contenedor.appendChild(article);
      });
    }

    inicializarReacciones();
  }

  function iniciar() {
    cargarDatosEventos();
    window.addEventListener('eventosActualizados', cargarDatosEventos);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
