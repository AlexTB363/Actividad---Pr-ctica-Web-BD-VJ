const API_URL = 'http://localhost:3000';

function sesionActual() {
  try { return JSON.parse(sessionStorage.getItem('sesion') || 'null'); } catch (e) { return null; }
}

function usuarioActual() {
  const s = sesionActual();
  if (s && s.id_usuario) return Number(s.id_usuario);
  const deUrl = new URLSearchParams(window.location.search).get('usuario');
  if (deUrl) sessionStorage.setItem('idUsuario', deUrl);
  return Number(sessionStorage.getItem('idUsuario') || 1);
}

async function api(ruta, opciones = {}) {
  let resp;
  try {
    resp = await fetch(API_URL + ruta, opciones);
  } catch (e) {
    throw new Error('No hay conexión con el servidor del kiosko. ¿Está encendido el API?');
  }
  let datos = null;
  try { datos = await resp.json(); } catch (e) {  }
  if (!resp.ok) throw new Error((datos && datos.error) || `Error ${resp.status}`);
  return datos;
}

function jsonBody(metodo, cuerpo) {
  return { method: metodo, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo) };
}

function esc(texto) {
  return String(texto ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function formatoFecha(iso, opciones = { day: '2-digit', month: '2-digit', year: 'numeric' }) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('es-MX', { timeZone: 'UTC', ...opciones });
}

function formatoPeriodo(inicio, fin) {
  const a = new Date(inicio), b = new Date(fin);
  const mes = (d) => d.toLocaleDateString('es-MX', { timeZone: 'UTC', month: 'short' }).replace('.', '');
  const dia = (d) => String(d.getUTCDate()).padStart(2, '0');
  const mismoMes = a.getUTCMonth() === b.getUTCMonth() && a.getUTCFullYear() === b.getUTCFullYear();
  return mismoMes
    ? `${dia(a)} – ${dia(b)} ${mes(b)} ${b.getUTCFullYear()}`
    : `${dia(a)} ${mes(a)} – ${dia(b)} ${mes(b)} ${b.getUTCFullYear()}`;
}

function formatoDinero(n) {
  return Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' });
}
