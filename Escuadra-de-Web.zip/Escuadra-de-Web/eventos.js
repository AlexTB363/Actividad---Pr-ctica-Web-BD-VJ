// Gestor de Eventos y Noticias Comunitarias para Empleados y Gerentes
(function () {
  const EVENTOS_DEFAULT = [
    {
      id: 'viernes-cafe',
      tipo: 'evento',
      activo: true,
      badge: 'Evento de Comunidad',
      badgeIcon: 'bi-cup-hot-fill',
      titulo: '☕ ¡Viernes Gratis hay Café! – Ven a convivir con el equipo',
      fecha: 'Todos los viernes',
      hora: '09:00 AM – 12:30 PM',
      lugar: 'Cafetería Central (Piso 2) & Terraza Garden',
      menu: 'Americano, Capuchino, Latte, Cold Brew y Pan Dulce',
      descripcion: 'Cerremos la semana con la mejor actitud y energía. Te invitamos a nuestra barra de café de especialidad y mesa de repostería artesanal. Es el momento perfecto para despejarte, charlar con compañeros de otras áreas y disfrutar una buena bebida caliente o fría por cortesía de People Tech.',
      fechaCreacion: 1710000002000,
      reacciones: [
        { id: 'cafe', icon: '☕', label: '¡Quiero café!', baseCount: 68 },
        { id: 'fiesta', icon: '🎉', label: '¡Ahí estaré!', baseCount: 53 },
        { id: 'pan', icon: '🥐', label: 'Con pan dulce', baseCount: 45 },
        { id: 'amor', icon: '❤️', label: '¡Gracias RH!', baseCount: 39 }
      ]
    },
    {
      id: 'guia-kiosko',
      tipo: 'guia',
      activo: true,
      badge: 'Guía y Orientación',
      badgeIcon: 'bi-compass-fill',
      titulo: 'Orientación oficial: Cómo aprovechar al máximo tu Kiosko People Tech',
      fecha: 'Lectura de 3 min',
      hora: '',
      lugar: '',
      menu: '',
      descripcion: 'El Kiosko es tu punto central de autoservicio laboral. Diseñado para simplificar trámites de Recursos Humanos, consultar tus ingresos y participar en dinámicas del equipo. Te explicamos paso a paso cada sección:',
      fechaCreacion: 1710000001000,
      reacciones: [
        { id: 'util', icon: '💡', label: 'Muy útil', baseCount: 42 },
        { id: 'amor', icon: '❤️', label: 'Me encanta', baseCount: 27 },
        { id: 'aplauso', icon: '👏', label: 'Excelente', baseCount: 19 }
      ]
    }
  ];

  const EventosManager = {
    CLAVE_STORAGE: 'peopletech_eventos_comunitarios',
    CLAVE_VISTAS: 'peopletech_noticias_vistas_ids',

    obtenerEventos() {
      let lista = [];
      try {
        const guardados = localStorage.getItem(this.CLAVE_STORAGE);
        if (guardados) {
          lista = JSON.parse(guardados);
        } else {
          lista = JSON.parse(JSON.stringify(EVENTOS_DEFAULT));
        }
      } catch (e) {
        console.warn('Error al leer eventos:', e);
        lista = JSON.parse(JSON.stringify(EVENTOS_DEFAULT));
      }

      // Ordenar por fecha de creación descendente (la más recientemente creada sale primero)
      lista.sort((a, b) => (Number(b.fechaCreacion) || 0) - (Number(a.fechaCreacion) || 0));
      return lista;
    },

    guardarEventos(lista) {
      try {
        localStorage.setItem(this.CLAVE_STORAGE, JSON.stringify(lista));
        window.dispatchEvent(new Event('eventosActualizados'));
        return true;
      } catch (e) {
        console.error('Error al guardar eventos:', e);
        return false;
      }
    },

    obtenerEvento(id) {
      const eventos = this.obtenerEventos();
      return eventos.find((e) => e.id === id) || null;
    },

    actualizarEvento(id, datosActualizados) {
      const eventos = this.obtenerEventos();
      const index = eventos.findIndex((e) => e.id === id);
      if (index !== -1) {
        eventos[index] = { ...eventos[index], ...datosActualizados };
      } else {
        eventos.push({ id, fechaCreacion: Date.now(), ...datosActualizados });
      }
      return this.guardarEventos(eventos);
    },

    crearNuevoEvento(nuevo) {
      const eventos = this.obtenerEventos();
      const id = nuevo.id || `evento-${Date.now()}`;
      const eventoFinal = {
        id,
        tipo: nuevo.tipo || 'evento',
        activo: nuevo.activo !== false,
        badge: nuevo.badge || 'Aviso de Comunidad',
        badgeIcon: nuevo.badgeIcon || 'bi-megaphone-fill',
        titulo: nuevo.titulo || 'Nueva Noticia',
        fecha: nuevo.fecha || 'Reciente',
        hora: nuevo.hora || '',
        lugar: nuevo.lugar || '',
        menu: nuevo.menu || '',
        descripcion: nuevo.descripcion || '',
        fechaCreacion: nuevo.fechaCreacion || Date.now(),
        reacciones: nuevo.reacciones || [
          { id: 'like', icon: '❤️', label: 'Me gusta', baseCount: 15 },
          { id: 'genial', icon: '🎉', label: 'Genial', baseCount: 10 },
          { id: 'aplauso', icon: '👏', label: 'Excelente', baseCount: 7 }
        ]
      };
      eventos.unshift(eventoFinal);
      this.guardarEventos(eventos);
      return eventoFinal;
    },

    eliminarEvento(id) {
      const eventos = this.obtenerEventos().filter((e) => e.id !== id);
      return this.guardarEventos(eventos);
    },

    restablecerEventos() {
      try {
        localStorage.removeItem(this.CLAVE_STORAGE);
        localStorage.removeItem(this.CLAVE_VISTAS);
        window.dispatchEvent(new Event('eventosActualizados'));
        return true;
      } catch (e) {
        return false;
      }
    },

    // Gestión de noticias no leídas / vistas
    obtenerNoticiasVistas() {
      try {
        return JSON.parse(localStorage.getItem(this.CLAVE_VISTAS) || '[]');
      } catch (e) {
        return [];
      }
    },

    marcarNoticiasComoVistas() {
      try {
        const activos = this.obtenerEventos().filter((e) => e.activo !== false);
        const ids = activos.map((e) => e.id);
        localStorage.setItem(this.CLAVE_VISTAS, JSON.stringify(ids));
        window.dispatchEvent(new Event('noticiasVistasActualizadas'));
      } catch (e) {
        console.warn('Error al marcar noticias vistas:', e);
      }
    },

    hayNoticiasSinVer() {
      const activos = this.obtenerEventos().filter((e) => e.activo !== false);
      const vistas = this.obtenerNoticiasVistas();
      // Si hay al menos un evento activo cuyo ID no está en vistas
      return activos.some((e) => !vistas.includes(e.id));
    }
  };

  window.EventosManager = EventosManager;
})();
