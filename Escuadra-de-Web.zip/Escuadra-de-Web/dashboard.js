const CLASE_ESTATUS_VAC = {
  'Pendiente': 'badge-pending',
  'Aprobada': 'badge-approved',
  'Rechazada': 'badge-rejected',
  'Cancelada': 'badge-rejected'
};

document.addEventListener('DOMContentLoaded', async () => {
  const sesion = sesionActual() || {};
  const usuario = usuarioActual();
  const $ = (id) => document.getElementById(id);

  const primerNombre = (sesion.nombre || sesion.nombre_usuario || '').split(' ')[0];
  $('saludo').textContent = primerNombre ? `Hola, ${primerNombre}` : 'Hola';

  if (sesion.es_gerente || sesion.es_admin) $('bannerGerente').classList.remove('d-none');

  try {
    const d = await api(`/api/usuarios/${usuario}/inicio`);

    if (d.nombre) $('saludo').textContent = `Hola, ${d.nombre.split(' ')[0]}`;

    const ultimo = d.recibos && d.recibos[0];
    $('ultimoPago').textContent = ultimo ? formatoDinero(ultimo.neto) : 'Sin recibos';
    $('ultimoPeriodo').textContent = ultimo ? formatoPeriodo(ultimo.periodo_inicio, ultimo.periodo_fin) : '';

    const disp = Number(d.dias_disponibles || 0);
    const tomados = Number(d.dias_tomados || 0);
    $('vacDisponibles').textContent = `${disp} disponibles`;
    $('vacTomados').textContent = `${tomados} tomados o pedidos este año`;
    $('vacNumero').textContent = disp;
    $('vacLabel').textContent = `días disponibles de ${Number(d.dias_asignados || 0)}`;

    $('numDocumentos').textContent = `${d.documentos} ${d.documentos === 1 ? 'archivo' : 'archivos'}`;
    $('telRH').textContent = d.telefono_rh || '—';
    $('extRH').textContent = d.extension_rh ? `Ext. ${d.extension_rh}` : '';

    $('listaRecibos').innerHTML = (d.recibos || []).length
      ? d.recibos.map((r) => `
          <div class="payroll-row">
            <div>
              <div class="payroll-period">${formatoPeriodo(r.periodo_inicio, r.periodo_fin)}</div>
              <div class="payroll-date">Pagado el ${formatoFecha(r.fecha_pago)}</div>
            </div>
            <div class="payroll-amount">${formatoDinero(r.neto)}</div>
          </div>`).join('')
      : '<div class="text-muted py-2">Todavía no tienes recibos.</div>';

    $('listaVacaciones').innerHTML = (d.vacaciones || []).length
      ? d.vacaciones.map((v) => `
          <div class="vacation-row">
            <span>${formatoFecha(v.fecha_inicio)} – ${formatoFecha(v.fecha_fin)}</span>
            <span class="badge-status ${CLASE_ESTATUS_VAC[v.estatus] || 'badge-pending'}">${esc(v.estatus)}</span>
          </div>`).join('')
      : '<div class="text-muted py-2">No has pedido vacaciones este año.</div>';
  } catch (e) {
    $('listaRecibos').innerHTML = `<div class="text-danger py-2">${esc(e.message)}</div>`;
  }

  // Sincronizar noticias comunitarias en el dashboard (las más recién creadas salen primero)
  if (window.EventosManager) {
    function sincronizarEventoDashboard() {
      const container = $('dashNewsRow');
      if (!container) return;

      const eventos = EventosManager.obtenerEventos(); // ya ordenados por fechaCreacion DESC
      const activos = eventos.filter((e) => e.activo !== false);

      if (activos.length === 0) {
        container.innerHTML = '<div class="col-12 text-muted py-3">No hay noticias o eventos activos en este momento.</div>';
        return;
      }

      container.innerHTML = activos.map((ev, index) => {
        const esMasReciente = index === 0;
        const tieneDetalles = Boolean(ev.hora || ev.lugar);
        const esCafe = ev.id === 'viernes-cafe';

        let bgStyle = 'background-color: var(--color-bg-app); border-color: var(--color-border);';
        let badgeClass = 'bg-primary-subtle text-primary';
        let btnClass = 'btn-outline-primary';

        if (esCafe) {
          bgStyle = 'background-color: #fffbeb; border-color: #fde68a !important;';
          badgeClass = 'bg-warning-subtle text-warning-emphasis';
          btnClass = 'btn-warning text-dark fw-semibold';
        } else if (esMasReciente && ev.id !== 'guia-kiosko') {
          bgStyle = 'background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-color: #bbf7d0 !important;';
          badgeClass = 'bg-success text-white';
          btnClass = 'btn-success text-white fw-semibold';
        }

        let detallesHtml = '';
        if (tieneDetalles) {
          detallesHtml = `
            <p class="small mb-3" style="${esCafe ? 'color: #92400e;' : 'color: var(--color-text-medium);'}">
              ${ev.hora ? `<i class="bi bi-alarm me-1"></i> <strong>${esc(ev.hora)}</strong>` : ''}
              ${ev.hora && ev.lugar ? ' &nbsp;•&nbsp; ' : ''}
              ${ev.lugar ? `<i class="bi bi-geo-alt me-1"></i> ${esc(ev.lugar)}` : ''}
            </p>
          `;
        } else {
          detallesHtml = `<p class="text-muted small mb-3">${esc(ev.descripcion || '')}</p>`;
        }

        return `
          <div class="col-md-6">
            <div class="p-3 border rounded-3 h-100 d-flex flex-column justify-content-between position-relative shadow-sm" style="${bgStyle}">
              <div>
                <div class="d-flex align-items-center gap-2 mb-2">
                  <span class="badge ${badgeClass}">${esc(ev.badge || 'Aviso')}</span>
                  ${esMasReciente ? '<span class="badge bg-danger rounded-pill"><i class="bi bi-stars"></i> Más reciente</span>' : ''}
                </div>
                <h5 class="fw-bold mb-1" style="${esCafe ? 'color: #78350f;' : 'color: var(--color-text-dark);'}">${esc(ev.titulo)}</h5>
                ${detallesHtml}
              </div>
              <a href="noticias.html#card-${ev.id}" class="btn btn-sm ${btnClass} align-self-start mt-2">
                ${tieneDetalles ? 'Ver evento y reaccionar' : 'Leer noticia completa'}
              </a>
            </div>
          </div>
        `;
      }).join('');
    }

    sincronizarEventoDashboard();
    window.addEventListener('eventosActualizados', sincronizarEventoDashboard);
  }
});
