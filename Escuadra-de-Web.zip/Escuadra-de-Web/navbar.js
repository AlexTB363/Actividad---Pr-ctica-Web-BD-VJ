function leerSesion() {
  try { return JSON.parse(sessionStorage.getItem('sesion') || 'null'); } catch (e) { return null; }
}

const sesionNavbar = leerSesion();
if (!sesionNavbar) window.location.replace('index.html');

async function loadNavbar() {
  const response = await fetch('navbar.html');
  const html = await response.text();

  const temp = document.createElement('div');
  temp.innerHTML = html;

  const header = temp.querySelector('#topbar');
  const sidebar = temp.querySelector('#sidebar');

  const headerPlaceholder = document.getElementById('header-placeholder');
  const sidebarPlaceholder = document.getElementById('sidebar-placeholder');

  if (headerPlaceholder) headerPlaceholder.replaceWith(header);
  if (sidebarPlaceholder) sidebarPlaceholder.replaceWith(sidebar);

  mostrarUsuario();
  highlightActiveLink();
  await inicializarNoticiasHeader();
}

async function asegurarEventosManager() {
  if (window.EventosManager) return Promise.resolve();
  return new Promise((resolve) => {
    const s = document.createElement('script');
    s.src = 'eventos.js';
    s.onload = resolve;
    s.onerror = resolve;
    document.head.appendChild(s);
  });
}

async function inicializarNoticiasHeader() {
  await asegurarEventosManager();

  const btn = document.getElementById('btnNewsHeader');
  const menu = document.getElementById('newsDropdownMenu');
  const badge = document.getElementById('newsUnreadBadge');
  const countEl = document.getElementById('newsDropdownCount');
  const listEl = document.getElementById('newsDropdownItems');

  if (!btn || !menu) return;

  function esc(t) {
    return String(t || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function renderDropdown() {
    if (!window.EventosManager) return;
    const todos = EventosManager.obtenerEventos();
    const activos = todos.filter((e) => e.activo !== false);

    // MÁXIMO 5 NOTICIAS (ordenadas por la más recién creada primero)
    const ultimas5 = activos.slice(0, 5);

    if (countEl) countEl.textContent = `${ultimas5.length} de ${activos.length}`;

    // Círculo rojo empalmando el icono cuando hay noticias sin ver
    const haySinVer = EventosManager.hayNoticiasSinVer();
    if (badge) {
      if (haySinVer) {
        badge.classList.add('has-unread');
      } else {
        badge.classList.remove('has-unread');
      }
    }

    if (listEl) {
      if (ultimas5.length === 0) {
        listEl.innerHTML = '<div class="p-3 text-center text-muted small">No hay noticias recientes</div>';
      } else {
        const vistas = EventosManager.obtenerNoticiasVistas();
        listEl.innerHTML = ultimas5.map((ev) => {
          const noVista = !vistas.includes(ev.id);
          return `
            <a href="noticias.html#card-${ev.id}" class="news-dropdown-item ${noVista ? 'fw-bold' : ''}">
              <div class="news-dropdown-item-meta mb-1">
                <span class="badge ${ev.id === 'viernes-cafe' ? 'bg-warning-subtle text-warning-emphasis' : 'bg-primary-subtle text-primary'} px-2 py-1" style="font-size:10px;">
                  ${esc(ev.badge || 'Aviso')}
                </span>
                <span class="text-muted" style="font-size:11px;">${esc(ev.fecha || 'Reciente')}</span>
              </div>
              <div class="news-dropdown-item-title">${esc(ev.titulo)}</div>
              <p class="news-dropdown-item-desc">${esc(ev.descripcion)}</p>
            </a>
          `;
        }).join('');
      }
    }
  }

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isShowing = menu.classList.contains('show');
    if (!isShowing) {
      menu.classList.add('show');
      // Al abrir el dropdown, marcar como vistas y apagar el círculo rojo
      if (window.EventosManager) {
        EventosManager.marcarNoticiasComoVistas();
      }
      if (badge) badge.classList.remove('has-unread');
    } else {
      menu.classList.remove('show');
    }
  });

  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && !btn.contains(e.target)) {
      menu.classList.remove('show');
    }
  });

  renderDropdown();

  window.addEventListener('eventosActualizados', renderDropdown);
  window.addEventListener('noticiasVistasActualizadas', renderDropdown);
}

function mostrarUsuario() {
  const s = sesionNavbar;
  if (!s) return;

  const nombre = document.querySelector('.user-name');
  const rol = document.querySelector('.user-role');
  if (nombre) nombre.textContent = s.nombre || s.nombre_usuario;
  if (rol) {
    const tipo = s.es_admin ? 'Administrador' : s.es_gerente ? 'Gerente' : 'Empleado';
    rol.textContent = s.numero_empleado ? `${tipo} · ${s.numero_empleado}` : tipo;
  }

  if (!s.es_admin && !s.es_gerente) {
    document.querySelectorAll('.sidebar a[href="gerente.html"]').forEach((a) => a.remove());
  }

  if (!s.es_admin) {
    document.querySelectorAll('.sidebar a[href="admin-headbreaker.html"], .sidebar a[href="admin-preguntas.html"], .sidebar a[href="admin-trivia.html"]').forEach((a) => a.remove());
  }

  const salir = document.querySelector('.btn-logout');
  if (salir) {
    salir.addEventListener('click', () => {
      sessionStorage.removeItem('sesion');
      sessionStorage.removeItem('idUsuario');
    });
  }
}

function highlightActiveLink() {
  const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';

  document.querySelectorAll('.sidebar .nav-link').forEach((link) => {
    if (link.getAttribute('href') === currentPage) {
      link.classList.add('active');
    }
  });
}

loadNavbar();
