document.addEventListener('DOMContentLoaded', () => {
  const usuario = usuarioActual();

  const form = document.getElementById('formTicket');
  const selTipo = document.getElementById('tipoIncidencia');
  const txtDescripcion = document.getElementById('descripcion');
  const inputEvidencia = document.getElementById('evidencia');
  const contador = document.getElementById('contador');
  const alerta = document.getElementById('formAlert');
  const btnEnviar = document.getElementById('btnEnviar');
  const lista = document.getElementById('ticketsList');

  const CLASE_ESTATUS = {
    'Abierto': 'badge-pending',
    'En proceso': 'badge-progress',
    'Resuelto': 'badge-approved',
    'Cerrado': 'badge-closed'
  };

  function mostrarAlerta(texto, tipo) {
    alerta.className = `alert alert-${tipo} mb-0`;
    alerta.textContent = texto;
  }

  async function cargarTipos() {
    try {
      const tipos = await api('/api/tickets/tipos');
      selTipo.innerHTML = '<option value="">Selecciona…</option>' +
        tipos.map((t) => `<option value="${t.id_tipo_incidencia}">${esc(t.descripcion)}</option>`).join('');
    } catch (e) {
      selTipo.innerHTML = '<option value="">No se pudieron cargar</option>';
      mostrarAlerta(e.message, 'danger');
    }
  }

  async function cargarTickets() {
    try {
      const tickets = await api(`/api/usuarios/${usuario}/tickets`);
      if (!tickets.length) {
        lista.innerHTML = '<div class="text-muted py-3">Todavía no has levantado reportes.</div>';
        return;
      }
      lista.innerHTML = tickets.map((t) => `
        <div class="list-group-item ticket-item">
          <div class="ticket-item-main">
            <div>
              <div class="ticket-folio">${esc(t.folio)}</div>
              <div class="ticket-tipo">${esc(t.tipo_incidencia)} · ${formatoFecha(t.fecha_creacion)}</div>
            </div>
            <span class="badge-status ${CLASE_ESTATUS[t.estatus] || 'badge-closed'}">${esc(t.estatus)}</span>
          </div>
          <div class="ticket-descripcion">${esc(t.descripcion)}</div>
          ${t.evidencia ? `<a class="ticket-evidencia" href="${API_URL}/${esc(t.evidencia)}" target="_blank" rel="noopener"><i class="bi bi-paperclip"></i> Ver evidencia</a>` : ''}
          ${t.respuesta ? `<div class="ticket-respuesta"><i class="bi bi-chat-left-text"></i> <strong>RH:</strong> ${esc(t.respuesta)}</div>` : ''}
        </div>`).join('');
    } catch (e) {
      lista.innerHTML = `<div class="text-danger py-3">${esc(e.message)}</div>`;
    }
  }

  txtDescripcion.addEventListener('input', () => {
    contador.textContent = txtDescripcion.value.length;
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!selTipo.value) return mostrarAlerta('Elige el tipo de incidencia.', 'danger');
    if (txtDescripcion.value.trim().length < 10) return mostrarAlerta('Describe el problema (mínimo 10 caracteres).', 'danger');

    const datos = new FormData();
    datos.append('usuario', usuario);
    datos.append('tipo', selTipo.value);
    datos.append('descripcion', txtDescripcion.value.trim());
    if (inputEvidencia.files[0]) datos.append('evidencia', inputEvidencia.files[0]);

    btnEnviar.disabled = true;
    try {
      const r = await api('/api/tickets', { method: 'POST', body: datos });
      mostrarAlerta(`Reporte enviado con folio ${r.folio}. Te avisaremos cuando RH responda.`, 'success');
      form.reset();
      contador.textContent = '0';
      cargarTickets();
    } catch (err) {
      mostrarAlerta(err.message, 'danger');
    } finally {
      btnEnviar.disabled = false;
    }
  });

  document.getElementById('btnRecargar').addEventListener('click', cargarTickets);

  cargarTipos();
  cargarTickets();
});
