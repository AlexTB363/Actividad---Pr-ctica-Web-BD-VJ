document.addEventListener('DOMContentLoaded', () => {
  const modalEl = document.getElementById('modalPassword');
  const form = document.getElementById('formPassword');
  const alertError = document.getElementById('passAlert');
  const alertSuccess = document.getElementById('passSuccess');

  const mostrarError = (msg) => {
    alertSuccess.classList.add('d-none');
    alertError.textContent = msg;
    alertError.classList.remove('d-none');
  };

  modalEl.addEventListener('shown.bs.modal', () => {
    form.reset();
    alertError.classList.add('d-none');
    alertSuccess.classList.add('d-none');
    document.getElementById('passActual').focus();
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alertError.classList.add('d-none');

    const actual = document.getElementById('passActual').value;
    const nueva = document.getElementById('passNueva').value;
    const confirmar = document.getElementById('passConfirmar').value;

    if (!actual || !nueva || !confirmar) {
      return mostrarError('Completa los tres campos para continuar.');
    }
    if (nueva.length < 8) {
      return mostrarError('La nueva contraseña debe tener al menos 8 caracteres.');
    }
    if (nueva !== confirmar) {
      return mostrarError('La confirmación no coincide con la nueva contraseña.');
    }
    if (nueva === actual) {
      return mostrarError('La nueva contraseña debe ser diferente a la actual.');
    }


    alertSuccess.classList.remove('d-none');

    setTimeout(() => {
      bootstrap.Modal.getInstance(modalEl).hide();
    }, 1200);
  });
});