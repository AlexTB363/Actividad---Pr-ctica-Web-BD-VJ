const nodemailer = require('nodemailer');

let transporter = null;
if (process.env.SMTP_HOST) {
  const port = Number(process.env.SMTP_PORT || 465);
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

async function sendCode(to, code) {
  if (!transporter) {
    console.log(`[2FA] SMTP no configurado. Código para ${to}: ${code}`);
    return;
  }
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    subject: 'Tu código de verificación - People Tech',
    text: `Tu código de verificación es ${code}. Vence en 5 minutos.`
  });
}

module.exports = { sendCode };